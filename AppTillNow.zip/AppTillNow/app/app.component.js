"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var AppComponent = (function () {
    function AppComponent() {
        this.name = 'Angular 5.0';
        this.courses = [
            { name: "ReactJS", duration: '3Days' },
            { name: "NodeJS", duration: '3Days' },
            { name: "jQuery", duration: '3Days' }
        ];
        this.location = "Pune";
        this.classToBeApplied = "Highlight";
        this.styleToBeApplied = "height:200px;width:200px";
        this.ImageUrl = "https://christianliebel.com/wp-content/uploads/2016/02/Angular2-825x510.png";
    }
    return AppComponent;
}());
AppComponent = __decorate([
    core_1.Component({
        selector: 'my-app',
        template: "<cart></cart>"
        // template:` 
        // <p *ngFor="let c of courses">
        // <course [coursedetails]="c" ></course>
        // </p>  
        // `  // template: `<h1> {{name}}  is conducted at {{location}}</h1>  
        // <img src={{ImageUrl}} height="200px" width="200px" />
        // <img [src]="ImageUrl" [ngClass]="classToBeApplied"  />
        // `
    })
], AppComponent);
exports.AppComponent = AppComponent;
//# sourceMappingURL=app.component.js.map