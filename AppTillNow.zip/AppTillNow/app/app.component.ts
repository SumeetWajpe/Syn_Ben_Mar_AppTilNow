import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template:`<cart></cart>`

  // template:` 


  // <p *ngFor="let c of courses">
  // <course [coursedetails]="c" ></course>
  // </p>  
  // `  // template: `<h1> {{name}}  is conducted at {{location}}</h1>  
  // <img src={{ImageUrl}} height="200px" width="200px" />
  // <img [src]="ImageUrl" [ngClass]="classToBeApplied"  />
  // `
})
export class AppComponent  { 
  name = 'Angular 5.0';
  courses:any=[
    {name:"ReactJS",duration:'3Days'},
    {name:"NodeJS",duration:'3Days'},
    {name:"jQuery",duration:'3Days'}    
  ];
  
  location:string="Pune";
  classToBeApplied:string="Highlight";
  styleToBeApplied:string="height:200px;width:200px"
  ImageUrl:string="https://christianliebel.com/wp-content/uploads/2016/02/Angular2-825x510.png"
 }
